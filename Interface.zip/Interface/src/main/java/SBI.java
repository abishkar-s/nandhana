
public class SBI implements Bank{
public float rateOfinterset() {return 9.15f;}
}
