
public interface Bank {
float rateOfinterset();

}
