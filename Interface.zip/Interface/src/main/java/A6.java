
public class A6  implements Printable {
	public void print() {System.out.println("hello");}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A6 a6=new A6();
		a6.print();

	}

}
