
public interface Printable {
	void run();
	

}
