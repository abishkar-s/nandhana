package redandrinight;

import java.io.FileReader;
import java.io.IOException;

public class FileReaderex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   try (FileReader reader = new FileReader("input.txt")) {
		
            int data;
            while ((data = reader.read()) != -1) {
                char character = (char) data;
                System.out.print(character);
            }
		   }
         catch (IOException e) {
            e.printStackTrace();
	}
	}
}