package redandrinight;

public class ArithmeticExceptions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
            int result = 10 / 0; // This will throw ArithmeticException
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero is not allowed.");
        } finally {
            System.out.println("End of operation.");
	}
	}
}


