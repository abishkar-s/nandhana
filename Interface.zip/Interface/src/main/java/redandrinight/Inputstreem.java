package redandrinight;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class Inputstreem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     try (InputStreamReader reader = new InputStreamReader(new FileInputStream("input.txt"), "UTF-8")) {
		            int data;
		            while ((data = reader.read()) != -1) {
		                char character = (char) data;
		                System.out.print(character);
		            }
		        } catch (IOException e) {
		        	e.printStackTrace();
		        }
	}
	     
}
