package redandrinight;

public class ArrayIndex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub;
		        int[] numbers = new int[5];		
        try {
            numbers[10] = 25; 
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: Index out of bounds.");
        } finally {
            System.out.println("Array operation finished.");
	}
	}
	}
