package redandrinight;

public class Null {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String text = null;	
        try {
            int length = text.length();  
        } catch (NullPointerException e) {
            System.out.println("Error: Null reference encountered.");
        } finally {
            System.out.println("Operation completed.");
	}
	}
}
