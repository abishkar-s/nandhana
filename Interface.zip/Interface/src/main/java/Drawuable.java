
public interface Drawuable {
void draw();
}
