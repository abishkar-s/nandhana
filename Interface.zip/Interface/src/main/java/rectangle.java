
public class   rectangle implements Drawuable {
public void draw () {System.out.println("drawing rectangle");}
}
	
	


