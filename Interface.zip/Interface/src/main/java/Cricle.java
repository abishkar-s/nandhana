
public class Cricle  implements Drawuable{
public void draw() {System.out.println("drawing cricle");}
}
