
public class PNB implements Bank  {
public float rateOfinterset() {return 9.7f;}
}
