
public class Testinterface2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Bank b= new SBI();
System.out.println("ROI:"+b.rateOfinterset());
	}

}
