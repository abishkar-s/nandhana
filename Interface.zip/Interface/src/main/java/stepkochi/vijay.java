package stepkochi;

public class vijay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Student s=new Student ();
     s.setName("vijay");
     System.out.println(s.getName());
	}

}
