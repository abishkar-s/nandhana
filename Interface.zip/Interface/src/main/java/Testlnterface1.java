
public class Testlnterface1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Drawuable d= new Cricle();
		d.draw();
		
	}

}
